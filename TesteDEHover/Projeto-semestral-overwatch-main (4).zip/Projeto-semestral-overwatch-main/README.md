# Projeto-semestral-overwatch
estamos aqui para melhorar e aprimorar nossas mentes
estamos aqui não apenas para um trabalho
nosso proposito é muito mais que apenas um projeto semestral
mas sim para romper nossos limites celebrais e fazer o melhor site que poderiamos fazer.
por enquanto é isso ai.
